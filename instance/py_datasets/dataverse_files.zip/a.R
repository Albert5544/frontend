## Code, executed in R 3.5.1 for Windows (64-bit)
## Attach relevant packages: mgcv (version 1.8-24) and ggplot2 (version 3.0.0)


